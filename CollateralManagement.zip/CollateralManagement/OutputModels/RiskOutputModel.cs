﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CollateralManagement.OutputModels
{
    public class RiskOutputModel
    {
        public string Collateral { get; set; }

        public string Type { get; set; }
    }
}
