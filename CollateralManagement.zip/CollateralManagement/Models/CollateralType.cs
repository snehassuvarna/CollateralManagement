﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CollateralManagement.Models
{
    public class CollateralType
    {
        public const string Land = "Land";
        public const string Gold = "Gold";
        public const string House = "House";
    }
}
